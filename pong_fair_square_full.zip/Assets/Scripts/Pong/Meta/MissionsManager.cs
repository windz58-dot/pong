using System;
using Pong.Profile;
using Pong.Telemetry;
using UnityEngine;

namespace Pong.Meta
{
    public sealed class MissionsManager : MonoBehaviour
    {
        public static MissionsManager I { get; private set; }

        private MissionConfig _cfg;
        private PlayerProfile _p;

        private string _dayKey;
        private int _playsToday;
        private int _scoresToday;
        private int _softLandToday;

        private void Awake()
        {
            if (I && I != this) { Destroy(gameObject); return; }
            I = this;
            DontDestroyOnLoad(gameObject);

            _cfg = MissionConfig.Load();
            _p = PlayerProfile.LoadOrCreate();
            LoadState();
            RotateDayIfNeeded();
        }

        private void RotateDayIfNeeded()
        {
            string today = DateTime.UtcNow.ToString("yyyyMMdd");
            if (_dayKey != today)
            {
                _dayKey = today;
                _playsToday = 0;
                _scoresToday = 0;
                _softLandToday = 0;
                SaveState();
            }
        }

        public void ReportPlayAttempt()
        {
            RotateDayIfNeeded();
            _playsToday++;
            SaveState();
            CheckMissions();
        }

        public void ReportScore()
        {
            RotateDayIfNeeded();
            _scoresToday++;
            SaveState();
            CheckMissions();
        }

        public void ReportSoftLand()
        {
            RotateDayIfNeeded();
            _softLandToday++;
            SaveState();
            CheckMissions();
        }

        private void CheckMissions()
        {
            if (_cfg?.daily == null) return;

            foreach (var m in _cfg.daily)
            {
                if (IsCompleted(m.id)) continue;
                int cur = CurrentFor(m.type);
                if (cur >= m.target)
                {
                    MarkCompleted(m.id);
                    GrantReward(m.reward);
                    TelemetryHub.I?.Track("mission_complete", new System.Collections.Generic.Dictionary<string, object>{
                        {"missionId", m.id}, {"reward", m.reward.display}
                    });
                }
            }
        }

        private int CurrentFor(string type)
        {
            return type switch
            {
                "PLAY_ATTEMPTS" => _playsToday,
                "SCORE_ANY" => _scoresToday,
                "SOFT_LAND" => _softLandToday,
                _ => 0
            };
        }

        private void GrantReward(MissionConfig.Reward r)
        {
            if (r == null) return;
            if (r.type == "CREDITS")
            {
                _p.credits += r.amount;
                _p.Save();
            }
            // cosmetics: just track owned flags (placeholder)
            if (r.type == "COSMETIC")
            {
                PlayerPrefs.SetInt("OWN_" + r.display, 1);
                PlayerPrefs.Save();
            }
        }

        private bool IsCompleted(string missionId) => PlayerPrefs.GetInt($"M_{_dayKey}_{missionId}", 0) == 1;
        private void MarkCompleted(string missionId)
        {
            PlayerPrefs.SetInt($"M_{_dayKey}_{missionId}", 1);
            PlayerPrefs.Save();
        }

        private void LoadState()
        {
            _dayKey = PlayerPrefs.GetString("M_DAY", DateTime.UtcNow.ToString("yyyyMMdd"));
            _playsToday = PlayerPrefs.GetInt("M_PLAYS", 0);
            _scoresToday = PlayerPrefs.GetInt("M_SCORES", 0);
            _softLandToday = PlayerPrefs.GetInt("M_SOFT", 0);
        }

        private void SaveState()
        {
            PlayerPrefs.SetString("M_DAY", _dayKey);
            PlayerPrefs.SetInt("M_PLAYS", _playsToday);
            PlayerPrefs.SetInt("M_SCORES", _scoresToday);
            PlayerPrefs.SetInt("M_SOFT", _softLandToday);
            PlayerPrefs.Save();
        }
    }
}
