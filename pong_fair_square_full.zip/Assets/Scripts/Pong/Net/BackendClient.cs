using System;
using System.Collections;
using Pong.Common;
using UnityEngine;
using UnityEngine.Networking;

namespace Pong.Net
{
    public sealed class BackendClient : MonoBehaviour
    {
        public static BackendClient I { get; private set; }

        private void Awake()
        {
            if (I && I != this) { Destroy(gameObject); return; }
            I = this;
            DontDestroyOnLoad(gameObject);
        }

        public IEnumerator PostJson(string path, string json, Action<string> ok, Action<string> err)
        {
            var url = PongConfig.Data.baseUrl.TrimEnd('/') + path;
            var req = new UnityWebRequest(url, "POST");
            byte[] body = System.Text.Encoding.UTF8.GetBytes(json ?? "{}");
            req.uploadHandler = new UploadHandlerRaw(body);
            req.downloadHandler = new DownloadHandlerBuffer();
            req.SetRequestHeader("Content-Type", "application/json");
            req.timeout = PongConfig.Data.timeoutSeconds;

            yield return req.SendWebRequest();

            if (req.result == UnityWebRequest.Result.Success) ok?.Invoke(req.downloadHandler.text);
            else err?.Invoke(req.error + " :: " + req.downloadHandler.text);
        }
    }
}
