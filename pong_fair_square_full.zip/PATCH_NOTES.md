## Files you must update/replace in your existing frontend:

### 1) BallController.cs
- Remove FindObjectOfType usage
- Add `SetUI(GameplayUIController ui)` and call it once from GameplayBootstrap
- Ensure ResetBall sets `rb.isKinematic = false`

### 2) PotTrigger.cs and HoleTrigger.cs
- Do NOT roll rewards locally
- Instead call RewardService.Reveal(...), then apply reward only after verification.

### 3) GameplayBootstrap.cs
- On attempt start: call RewardService.CommitBeforeAttempt(...)
- Store pending event in RewardService (per attempt)
- On score: provide bucket/eligibility/shot telemetry and request reveal.

This patch includes drop-in replacements for these scripts (same namespaces) so Unity will compile with minimal manual edits.
