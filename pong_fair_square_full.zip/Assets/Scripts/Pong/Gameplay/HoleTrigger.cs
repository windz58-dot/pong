using Pong.Rewards;
using UnityEngine;

namespace Pong.Gameplay
{
    [RequireComponent(typeof(Collider))]
    public sealed class HoleTrigger : MonoBehaviour
    {
        [SerializeField] private float captureMaxSpeed = 1.4f;
        [SerializeField] private string bucket = "CREDITS";

        private void Reset()
        {
            var c = GetComponent<Collider>();
            c.isTrigger = true;
        }

        private void OnTriggerEnter(Collider other)
        {
            var ball = other.GetComponent<BallController>();
            if (!ball) return;

            var rb = other.GetComponent<Rigidbody>();
            bool soft = (rb != null && rb.velocity.magnitude <= captureMaxSpeed * 0.55f);
            if (rb && rb.velocity.magnitude > captureMaxSpeed) return;

            var shot = GameplayShotSampler.Sample(ball);
            RewardService.I.RevealAfterEligibility(
                Pong.Profile.PlayerProfile.LoadOrCreate().playerId,
                bucket,
                potIndex: -1,
                wheelUnlocked: false,
                shot: shot,
                onOk: resp =>
                {
                    if (soft) Pong.Meta.MissionsManager.I?.ReportSoftLand();
                {
                    var reward = RewardMapper.ToLocal(resp.reward);
                    ball.Score(reward);
                }
                ,
                onErr: err =>
                {
                    Debug.LogError("Reveal failed: " + err);
                    ball.Score(RewardResult.Credits(10));
                });
        }
    }
}
