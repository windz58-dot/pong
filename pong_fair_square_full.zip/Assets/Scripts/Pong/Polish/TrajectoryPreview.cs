using UnityEngine;

namespace Pong.Polish
{
    [RequireComponent(typeof(LineRenderer))]
    public sealed class TrajectoryPreview : MonoBehaviour
    {
        [Header("Refs")]
        [SerializeField] private Rigidbody ballRb;
        [SerializeField] private LineRenderer line;

        [Header("Sim")]
        [SerializeField] private int steps = 28;
        [SerializeField] private float timeStep = 0.06f;
        [SerializeField] private LayerMask collisionMask = ~0;
        [SerializeField] private float sphereRadius = 0.02f;
        [SerializeField] private float maxDistance = 12f;

        [Header("Visual")]
        [SerializeField] private bool showWhenCharging = true;

        private Vector3 _startPos;
        private Vector3 _startVel;
        private bool _active;

        public void SetActive(bool on)
        {
            _active = on;
            if (line) line.enabled = on;
        }

        public void Preview(Vector3 startPos, Vector3 initialVelocity)
        {
            _startPos = startPos;
            _startVel = initialVelocity;
        }

        private void Awake()
        {
            if (!line) line = GetComponent<LineRenderer>();
            if (line) line.positionCount = 0;
            SetActive(false);
        }

        private void LateUpdate()
        {
            if (!_active || !line) return;

            var p = _startPos;
            var v = _startVel;

            line.positionCount = steps;
            float traveled = 0f;

            for (int i = 0; i < steps; i++)
            {
                line.SetPosition(i, p);

                // integrate
                v += Physics.gravity * timeStep;
                var next = p + v * timeStep;

                // collision (sphere cast)
                var dir = next - p;
                float dist = dir.magnitude;
                if (dist > 0.0001f)
                {
                    dir /= dist;
                    if (Physics.SphereCast(p, sphereRadius, dir, out var hit, dist, collisionMask, QueryTriggerInteraction.Ignore))
                    {
                        // stop at collision point
                        line.SetPosition(i, hit.point);
                        // truncate
                        line.positionCount = i + 1;
                        break;
                    }
                }

                traveled += dist;
                if (traveled > maxDistance)
                {
                    line.positionCount = i + 1;
                    break;
                }

                p = next;
            }
        }
    }
}
