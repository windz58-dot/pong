using System;
using UnityEngine;

namespace Pong.Common
{
    [Serializable]
    public sealed class PongConfigData
    {
        public string baseUrl;
        public int timeoutSeconds = 10;
        public Endpoints endpoints = new Endpoints();
        public Economy economy = new Economy();

        [Serializable] public sealed class Endpoints
        {
            public string sessionStart;
            public string attemptCommit;
            public string rewardReveal;
            public string profile;
            public string leaderboard;
        }

        [Serializable] public sealed class Economy
        {
            public int freeAttemptsPerDay = 3;
            public int paidAttemptCostCredits = 25;
            public float powerCurveGamma = 1.85f;
            public float maxImpulse = 4.8f;
            public float spinFriction = 0.22f;
        }
    }

    public static class PongConfig
    {
        private static PongConfigData _data;
        public static PongConfigData Data
        {
            get
            {
                if (_data == null)
                {
                    var ta = Resources.Load<TextAsset>("PongConfig");
                    _data = ta ? JsonUtility.FromJson<PongConfigData>(ta.text) : new PongConfigData();
                }
                return _data;
            }
        }
    }
}
