using System.Collections;
using TMPro;
using UnityEngine;

namespace Pong.Boot
{
    public sealed class LoadingTipsRotator : MonoBehaviour
    {
        [SerializeField] private TMP_Text tipsText;
        [SerializeField] private float changeEverySeconds = 1.8f; // 1.4–2.2
        [SerializeField] private float fadeSeconds = 0.16f;       // 0.12–0.22
        [SerializeField] private string[] tips = new[]
        {
            "Tip: Feather the power to land softly in the cup.",
            "Tip: A tiny spin can stabilize your roll.",
            "Tip: Bounce off rails to reach hard angles.",
            "Tip: Consistency beats luck — master your timing.",
            "Tip: Rare spins are earned — keep pushing."
        };

        private Coroutine _co;

        public void Configure(TMP_Text text, float every, float fade)
        {
            tipsText = text;
            changeEverySeconds = Mathf.Clamp(every, 1.4f, 2.2f);
            fadeSeconds = Mathf.Clamp(fade, 0.12f, 0.22f);
        }

        private void OnEnable()
        {
            if (_co != null) StopCoroutine(_co);
            _co = StartCoroutine(Run());
        }

        private IEnumerator Run()
        {
            if (!tipsText || tips.Length == 0) yield break;

            var cg = tipsText.GetComponent<CanvasGroup>();
            if (!cg) cg = tipsText.gameObject.AddComponent<CanvasGroup>();

            int idx = Random.Range(0, tips.Length);
            tipsText.text = tips[idx];
            cg.alpha = 1f;

            while (true)
            {
                yield return new WaitForSecondsRealtime(changeEverySeconds);

                for (float t=0; t<fadeSeconds; t += Time.unscaledDeltaTime)
                {
                    cg.alpha = Mathf.Lerp(1f, 0f, t / fadeSeconds);
                    yield return null;
                }
                cg.alpha = 0f;

                idx = (idx + 1 + Random.Range(0, tips.Length-1)) % tips.Length;
                tipsText.text = tips[idx];

#if UNITY_IOS || UNITY_ANDROID
                Handheld.Vibrate();
#endif
                for (float t=0; t<fadeSeconds; t += Time.unscaledDeltaTime)
                {
                    cg.alpha = Mathf.Lerp(0f, 1f, t / fadeSeconds);
                    yield return null;
                }
                cg.alpha = 1f;
            }
        }
    }
}
