using System;
using UnityEngine;

namespace Pong.Rewards
{
    [Serializable] public sealed class RiskResult { public float risk_score; public bool high_risk; }

    [Serializable] public sealed class RewardCommitRequest
    {
        public string playerId;
        public string sessionId;
        public string clientSeed;
        public ulong nonce;
        public Context context = new Context();

        [Serializable] public sealed class Context
        {
            public string mode;   // "daily" | "paid"
            public string build;
            public string deviceId;
        }
    }

    [Serializable] public sealed class RewardCommitResponse
    {
        public string eventId;
        public string serverSeedHash;
        public string configVersion;
        public string configHash;
        public string expiresAt;
        public RiskResult risk;
    }

    [Serializable] public sealed class RewardRevealRequest
    {
        public string playerId;
        public string eventId;
        public string bucket; // WHEEL_UNLOCK/CREDITS/ITEM/UTILITY
        public Eligibility eligibility = new Eligibility();
        public Shot shot = new Shot();

        [Serializable] public sealed class Eligibility
        {
            public int potIndex;
            public bool wheelUnlocked;
        }
        [Serializable] public sealed class Shot
        {
            public float power01;
            public float flightSeconds;
            public int bounces;
        }
    }

    [Serializable] public sealed class RewardEntry
    {
        public string id;
        public string type;
        public float amount;
        public string display;
    }

    [Serializable] public sealed class CapsApplied
    {
        public bool killSwitch;
        public bool userCooldownBlocked;
        public bool budgetBlocked;
        public bool evBlocked;
    }

    [Serializable] public sealed class RewardRevealResponse
    {
        public string auditId;
        public string eventId;
        public string serverSeed;
        public string serverSeedHash;
        public string clientSeed;
        public ulong nonce;
        public string rand;
        public RewardEntry reward;
        public CapsApplied capsApplied;
        public RiskResult risk;
    }
}
