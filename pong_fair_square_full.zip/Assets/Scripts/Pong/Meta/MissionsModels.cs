using System;
using UnityEngine;

namespace Pong.Meta
{
    [Serializable] public sealed class MissionConfig
    {
        public string version = "v1";
        public Mission[] daily;
        public Streak streak;

        [Serializable] public sealed class Mission
        {
            public string id;
            public string type; // PLAY_ATTEMPTS, SCORE_ANY, SOFT_LAND
            public int target;
            public Reward reward;
        }

        [Serializable] public sealed class Streak
        {
            public int everyDays = 7;
            public Reward reward;
        }

        [Serializable] public sealed class Reward
        {
            public string type; // CREDITS, COSMETIC
            public int amount;
            public string display;
        }

        public static MissionConfig Load()
        {
            var ta = Resources.Load<TextAsset>("PongMissions");
            return ta ? JsonUtility.FromJson<MissionConfig>(ta.text) : new MissionConfig();
        }
    }
}
