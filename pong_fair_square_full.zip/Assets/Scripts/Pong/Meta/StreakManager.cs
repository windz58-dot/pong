using System;
using Pong.Profile;
using Pong.Telemetry;
using UnityEngine;

namespace Pong.Meta
{
    public sealed class StreakManager : MonoBehaviour
    {
        public static StreakManager I { get; private set; }

        private PlayerProfile _p;
        private MissionConfig _cfg;
        private string _lastDay;
        private int _streak;

        private void Awake()
        {
            if (I && I != this) { Destroy(gameObject); return; }
            I = this;
            DontDestroyOnLoad(gameObject);

            _p = PlayerProfile.LoadOrCreate();
            _cfg = MissionConfig.Load();

            _lastDay = PlayerPrefs.GetString("S_LAST", "");
            _streak = PlayerPrefs.GetInt("S_CNT", 0);

            TouchToday();
        }

        public void TouchToday()
        {
            string today = DateTime.UtcNow.ToString("yyyyMMdd");
            if (_lastDay == today) return;

            if (!string.IsNullOrEmpty(_lastDay))
            {
                var last = DateTime.ParseExact(_lastDay, "yyyyMMdd", null);
                var now = DateTime.ParseExact(today, "yyyyMMdd", null);
                if ((now - last).TotalDays <= 1.1) _streak++;
                else _streak = 1;
            }
            else _streak = 1;

            _lastDay = today;
            PlayerPrefs.SetString("S_LAST", _lastDay);
            PlayerPrefs.SetInt("S_CNT", _streak);
            PlayerPrefs.Save();

            TelemetryHub.I?.Track("streak_touch", new System.Collections.Generic.Dictionary<string, object>{{"streak", _streak}});

            if (_cfg?.streak != null && _streak % _cfg.streak.everyDays == 0)
            {
                // reward cosmetic only
                PlayerPrefs.SetInt("OWN_" + _cfg.streak.reward.display, 1);
                PlayerPrefs.Save();
                TelemetryHub.I?.Track("streak_reward", new System.Collections.Generic.Dictionary<string, object>{{"reward", _cfg.streak.reward.display}});
            }
        }
    }
}
