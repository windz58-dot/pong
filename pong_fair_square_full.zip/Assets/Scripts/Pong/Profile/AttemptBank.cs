using Pong.Common;
using UnityEngine;

namespace Pong.Profile
{
    public static class AttemptBank
    {
        public static bool TryConsumeAttempt(PlayerProfile profile)
        {
            profile.DailyResetIfNeeded(PongConfig.Data.economy.freeAttemptsPerDay);

            if (profile.freeAttemptsRemaining > 0)
            {
                profile.freeAttemptsRemaining--;
                profile.Save();
                return true;
            }
            if (profile.paidAttempts > 0)
            {
                profile.paidAttempts--;
                profile.Save();
                return true;
            }
            return false;
        }

        public static void GrantPaidAttempts(PlayerProfile profile, int count)
        {
            profile.paidAttempts += Mathf.Max(0, count);
            profile.Save();
        }
    }
}
