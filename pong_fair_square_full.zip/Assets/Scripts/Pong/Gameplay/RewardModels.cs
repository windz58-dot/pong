using System;

namespace Pong.Gameplay
{
    public enum RewardType { None, Credits, WheelSpin, CosmeticItem, PaidAttempt, CryptoPi1, CryptoPi10 }

    [Serializable]
    public sealed class RewardResult
    {
        public RewardType type;
        public int amount;
        public string DisplayText;

        public static RewardResult Credits(int amt) => new RewardResult{ type=RewardType.Credits, amount=amt, DisplayText=$"+{amt} Credits" };
        public static RewardResult PaidAttempt(int amt) => new RewardResult{ type=RewardType.PaidAttempt, amount=amt, DisplayText=$"+{amt} Extra Attempt" };
        public static RewardResult WheelSpin() => new RewardResult{ type=RewardType.WheelSpin, amount=1, DisplayText="Wheel Spin Unlocked" };
        public static RewardResult Cosmetic(string name) => new RewardResult{ type=RewardType.CosmeticItem, amount=1, DisplayText=$"Item: {name}" };
        public static RewardResult Pi1() => new RewardResult{ type=RewardType.CryptoPi1, amount=1, DisplayText="Rare Bonus: 1 PI" };
        public static RewardResult Pi10() => new RewardResult{ type=RewardType.CryptoPi10, amount=10, DisplayText="Ultra-Rare Bonus: 10 PI" };
    }
}
