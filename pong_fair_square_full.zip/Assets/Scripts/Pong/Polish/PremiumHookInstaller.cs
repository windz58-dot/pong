using Pong.Gameplay;
using UnityEngine;

namespace Pong.Polish
{
    // Connects AimStrikeController events to PremiumGameplayBinder without editing core scripts.
    // Attach this to the same object as PremiumGameplayBinder (or GameplayRoot).
    public sealed class PremiumHookInstaller : MonoBehaviour
    {
        [SerializeField] private AimStrikeController aim;
        [SerializeField] private PremiumGameplayBinder binder;

        private void Awake()
        {
            if (!aim) aim = FindObjectOfType<AimStrikeController>();
            if (!binder) binder = FindObjectOfType<PremiumGameplayBinder>();

            if (aim != null && binder != null)
            {
                aim.OnCharging += (dir, p01) => binder.UpdatePreview(dir, p01);
                aim.OnStrikePower += (p01) => { binder.HidePreview(); binder.NotifyStrike(p01); };
            }
        }

        private void OnDisable()
        {
            // Events auto-cleared with object lifecycle; no-op.
        }
    }
}
