package server

import "math"

type ShotTelemetry struct {
	Power01       float64 `json:"power01"`
	FlightSeconds float64 `json:"flightSeconds"`
	Bounces       int     `json:"bounces"`
	MaxSpeed      float64 `json:"maxSpeed"`
}

type PlausibilityResult struct {
	Anomaly01 float64
	Reason    string
}

// Example plausibility checks (tune with your physics):
// - MaxSpeed upper bound by your impulse cap
// - FlightSeconds sane range
// - Bounce count reasonable
func CheckShot(t ShotTelemetry) PlausibilityResult {
	anom := 0.0
	reason := ""

	// Speed bounds (Unity units): if your max impulse yields ~10 m/s typical, cap at 18
	if t.MaxSpeed > 18 {
		anom = math.Max(anom, clamp01((t.MaxSpeed-18)/10))
		reason = "maxSpeed too high"
	}

	if t.FlightSeconds < 0 || t.FlightSeconds > 30 {
		anom = math.Max(anom, 0.6)
		reason = "flightSeconds out of range"
	}

	if t.Bounces < 0 || t.Bounces > 25 {
		anom = math.Max(anom, 0.4)
		reason = "bounces out of range"
	}

	return PlausibilityResult{Anomaly01: anom, Reason: reason}
}

func clamp01(x float64) float64 {
	if x < 0 { return 0 }
	if x > 1 { return 1 }
	return x
}
