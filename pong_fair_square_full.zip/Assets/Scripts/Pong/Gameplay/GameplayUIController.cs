using Pong.Profile;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace Pong.Gameplay
{
    public sealed class GameplayUIController : MonoBehaviour
    {
        [SerializeField] private TMP_Text attemptsText;
        [SerializeField] private TMP_Text speedText;

        [SerializeField] private Image powerFill;
        [SerializeField] private TMP_Text powerText;

        [SerializeField] private GameObject resultPanel;
        [SerializeField] private TMP_Text resultTitle;
        [SerializeField] private TMP_Text rewardText;
        [SerializeField] private Button playAgainButton;
        [SerializeField] private Button backToMenuButton;

        public void Bind(PlayerProfile p)
        {
            if (backToMenuButton) backToMenuButton.onClick.AddListener(() => SceneManager.LoadScene("MainMenu"));
            RefreshAttempts(p);
        }

        public void SetPower(float p01)
        {
            if (powerFill) powerFill.fillAmount = Mathf.Clamp01(p01);
            if (powerText) powerText.text = Mathf.RoundToInt(p01 * 100f) + "%";
        }

        public void SetSpeed(float mps) { if (speedText) speedText.text = $"{mps:0.0} m/s"; }

        public void OnAttemptStarted(PlayerProfile p)
        {
            RefreshAttempts(p);
            if (resultPanel) resultPanel.SetActive(false);
        }

        public void ShowMiss(System.Action onContinue)
        {
            if (resultPanel) resultPanel.SetActive(true);
            if (resultTitle) resultTitle.text = "Miss";
            if (rewardText) rewardText.text = "Try a different angle.";
            if (playAgainButton)
            {
                playAgainButton.onClick.RemoveAllListeners();
                playAgainButton.onClick.AddListener(() => onContinue?.Invoke());
            }
        }

        public void ShowOutOfAttempts()
        {
            if (resultPanel) resultPanel.SetActive(true);
            if (resultTitle) resultTitle.text = "Out of Attempts";
            if (rewardText) rewardText.text = "Get more attempts in Store.";
            if (playAgainButton)
            {
                playAgainButton.onClick.RemoveAllListeners();
                playAgainButton.onClick.AddListener(() => SceneManager.LoadScene("MainMenu"));
            }
        }

        public void ShowReward(RewardResult reward, PlayerProfile p, System.Action onContinue)
        {
            if (resultPanel) resultPanel.SetActive(true);
            if (resultTitle) resultTitle.text = "Success!";
            if (rewardText) rewardText.text = reward.DisplayText;

            Pong.Audio.AudioManager.I?.SfxSuccess();
            ApplyReward(reward, p);
            RefreshAttempts(p);

            if (playAgainButton)
            {
                playAgainButton.onClick.RemoveAllListeners();
                playAgainButton.onClick.AddListener(() => onContinue?.Invoke());
            }
        }

        private void ApplyReward(RewardResult reward, PlayerProfile p)
        {
            if (reward.type == RewardType.Credits)
            {
                p.credits += reward.amount;
                p.Save();
            }
            else if (reward.type == RewardType.PaidAttempt)
            {
                AttemptBank.GrantPaidAttempts(p, reward.amount);
            }
        }

        private void RefreshAttempts(PlayerProfile p)
        {
            if (attemptsText) attemptsText.text = $"{p.freeAttemptsRemaining} free / {p.paidAttempts} paid";
        }
    }
}
