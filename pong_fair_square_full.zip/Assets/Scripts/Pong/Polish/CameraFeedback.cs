using UnityEngine;

namespace Pong.Polish
{
    public sealed class CameraFeedback : MonoBehaviour
    {
        [Header("Refs")]
        [SerializeField] private Transform followTarget; // ball or focal point
        [SerializeField] private Transform cameraTransform;

        [Header("Follow")]
        [SerializeField] private Vector3 followOffset = new Vector3(0, 1.15f, -2.6f);
        [SerializeField] private float followSmooth = 9.0f;

        [Header("Hit Zoom")]
        [SerializeField] private float zoomKick = 0.12f;
        [SerializeField] private float zoomReturn = 10.0f;

        [Header("Shake")]
        [SerializeField] private float shakeAmount = 0.07f;
        [SerializeField] private float shakeDecay = 10.0f;

        private Vector3 _baseOffset;
        private float _shake;
        private float _zoom;

        private void Awake()
        {
            if (!cameraTransform) cameraTransform = transform;
            _baseOffset = followOffset;
        }

        public void OnStrike(float power01)
        {
            // subtle whoosh/zoom based on power
            _zoom = Mathf.Max(_zoom, zoomKick * Mathf.Lerp(0.65f, 1.2f, power01));
            _shake = Mathf.Max(_shake, shakeAmount * Mathf.Lerp(0.35f, 1.0f, power01));
        }

        public void OnScore()
        {
            _shake = Mathf.Max(_shake, shakeAmount * 1.25f);
            _zoom = Mathf.Max(_zoom, zoomKick * 1.35f);
        }

        private void LateUpdate()
        {
            if (!followTarget || !cameraTransform) return;

            // Smooth follow
            var desired = followTarget.position + _baseOffset;
            cameraTransform.position = Vector3.Lerp(cameraTransform.position, desired, 1f - Mathf.Exp(-followSmooth * Time.deltaTime));
            cameraTransform.LookAt(followTarget.position + Vector3.up * 0.08f);

            // Decay
            _shake = Mathf.MoveTowards(_shake, 0f, shakeDecay * Time.deltaTime);
            _zoom = Mathf.MoveTowards(_zoom, 0f, zoomReturn * Time.deltaTime);

            // Apply offsets (micro premium feel)
            var shakeVec = new Vector3(
                (Mathf.PerlinNoise(Time.time * 23.1f, 0.3f) - 0.5f),
                (Mathf.PerlinNoise(0.7f, Time.time * 21.7f) - 0.5f),
                0f) * _shake;

            cameraTransform.position += shakeVec;
            cameraTransform.position += cameraTransform.forward * _zoom;
        }
    }
}
