# Risk Scoring (outputs: risk_score, high_risk)

Goal: protect economy from bots/farms/exploits while minimizing false positives.

## Inputs (normalized to 0..1 where possible)
- account_age_days
- attempts_per_minute
- win_rate_7d (wheel unlocks / attempts)
- device_uniqueness (how many accounts per device in 7d)
- ip_entropy (distinct accounts per /24)
- shot_physics_anomaly (server-side check 0..1)
- payment_chargeback_risk (0..1, from Stripe Radar or internal)

## Formula (deterministic)
Let:
A = clamp01(1 - min(account_age_days, 30)/30)           # new accounts higher risk
B = clamp01((attempts_per_minute - 0.6)/2.0)            # >0.6/min ramps risk
C = clamp01((win_rate_7d - 0.02)/0.10)                  # unusually high wheel unlock rate
D = clamp01((device_uniqueness - 2)/8)                  # >2 accounts/device ramps
E = clamp01((ip_entropy - 3)/12)                        # >3 accounts/IP range ramps
F = clamp01(shot_physics_anomaly)                       # impossible shots
G = clamp01(payment_chargeback_risk)

risk_score = 100 * (0.18*A + 0.16*B + 0.14*C + 0.12*D + 0.10*E + 0.22*F + 0.08*G)

high_risk = (risk_score >= 70) OR (F >= 0.85)

## Behavior
- high_risk true => crypto blocked, rare cosmetics throttled, still allows play.
- risk_score >= 85 => shadow-restrict leaderboard submissions pending review.

This formula is stable and auditable.
