using UnityEngine;

namespace Pong.Audio
{
    public sealed class AudioManager : MonoBehaviour
    {
        public static AudioManager I { get; private set; }

        [SerializeField] private AudioSource music;
        [SerializeField] private AudioSource sfx;
        [SerializeField] private AudioSource ambience;

        public AudioClip bootHum;
        public AudioClip whoosh;
        public AudioClip successShimmer;
        public AudioClip menuMusic;

        private void Awake()
        {
            if (I && I != this) { Destroy(gameObject); return; }
            I = this;
            DontDestroyOnLoad(gameObject);

            if (!music) music = gameObject.AddComponent<AudioSource>();
            if (!sfx) sfx = gameObject.AddComponent<AudioSource>();
            if (!ambience) ambience = gameObject.AddComponent<AudioSource>();

            music.loop = true;
            ambience.loop = true;

            music.spatialBlend = 0f;
            ambience.spatialBlend = 0f;
            music.panStereo = -0.12f;
            ambience.panStereo = 0.12f;
        }

        public void PlayBootAmbience()
        {
            if (bootHum && !ambience.isPlaying)
            {
                ambience.clip = bootHum;
                ambience.volume = 0.22f;
                ambience.Play();
            }
        }

        public void TransitionToMenu()
        {
            if (menuMusic)
            {
                music.clip = menuMusic;
                music.volume = 0.28f;
                if (!music.isPlaying) music.Play();
            }
        }

        public void SfxWhoosh(float vol=0.35f) { if (whoosh) sfx.PlayOneShot(whoosh, vol); }
        public void SfxSuccess(float vol=0.55f) { if (successShimmer) sfx.PlayOneShot(successShimmer, vol); }
    }
}
