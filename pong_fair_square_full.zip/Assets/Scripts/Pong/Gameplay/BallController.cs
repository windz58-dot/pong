using System;
using UnityEngine;

namespace Pong.Gameplay
{
    [RequireComponent(typeof(Rigidbody))]
    public sealed class BallController : MonoBehaviour
    {
        public event Action OnStopped;
        public event Action<RewardResult> OnScored;

        [SerializeField] private Rigidbody rb;
        [SerializeField] private float stopSpeed = 0.08f;
        [SerializeField] private float stopSeconds = 1.0f;
        [SerializeField] private Transform spawnPoint;

        private GameplayUIController _ui;
        [SerializeField] private ShotTracker shotTracker;
        private float _stillTime;
        private bool _canStrike = true;
        private bool _scored;

        public bool CanStrike => _canStrike && !_scored;
        public Rigidbody RB => rb;

        private void Awake()
        {
            if (!rb) rb = GetComponent<Rigidbody>();
            if (!shotTracker) shotTracker = FindObjectOfType<ShotTracker>();
        }

        public void SetUI(GameplayUIController ui) => _ui = ui;

        public void ResetBall()
        {
            _scored = false;
            _canStrike = true;
            _stillTime = 0f;

            if (spawnPoint)
            {
                transform.position = spawnPoint.position;
                transform.rotation = spawnPoint.rotation;
            }

            rb.isKinematic = false;        // FIX: always reset
            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
            rb.Sleep();
        }

        public void Strike(Vector3 dir, float impulseMag, float spinFriction)
        {
            if (!CanStrike) return;
            _canStrike = false;

            shotTracker?.OnStrike(impulseMag <= 0 ? 0f : Mathf.Clamp01(impulseMag / 4.8f));

            rb.WakeUp();
            rb.AddForce(dir * impulseMag, ForceMode.Impulse);

            var spinAxis = Vector3.Cross(Vector3.up, dir).normalized;
            rb.AddTorque(spinAxis * impulseMag * spinFriction, ForceMode.Impulse);
        }

        private void FixedUpdate()
        {
            if (_scored) return;

            float speed = rb.velocity.magnitude;
            _ui?.SetSpeed(speed);

            if (!_canStrike)
            {
                if (speed <= stopSpeed)
                {
                    _stillTime += Time.fixedDeltaTime;
                    if (_stillTime >= stopSeconds)
                    {
                        OnStopped?.Invoke();
                        _canStrike = true;
                    }
                }
                else _stillTime = 0f;
            }
        }

        public void Score(RewardResult reward)
        {
            if (_scored) return;
            _scored = true;

            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
            rb.isKinematic = true; // freeze during reveal
            OnScored?.Invoke(reward);
        }
    }
private void OnCollisionEnter(Collision collision)
{
    // count only meaningful bounces (ignore tiny contacts)
    if (collision != null && collision.relativeVelocity.magnitude > 0.35f)
        shotTracker?.OnPhysicsContact();
}

}
