using Pong.Rewards;
using UnityEngine;

namespace Pong.Gameplay
{
    public static class GameplayShotSampler
    {
        public static ShotTelemetry Sample(BallController ball)
        {
            var tracker = Object.FindObjectOfType<ShotTracker>();
            var rb = ball ? ball.RB : null;

            return new ShotTelemetry
            {
                power01 = tracker ? tracker.Power01 : 0f,
                flightSeconds = tracker ? tracker.FlightSeconds : 0f,
                bounces = tracker ? tracker.Bounces : 0,
                maxSpeed = tracker ? tracker.MaxSpeed : (rb ? rb.velocity.magnitude : 0f)
            };
        }
    }
}
