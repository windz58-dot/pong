using System;
using System.Security.Cryptography;
using System.Text;

namespace Pong.Rewards
{
    public static class ProvableFairness
    {
        public static string Sha256Hex(string s)
        {
            using var sha = SHA256.Create();
            var b = sha.ComputeHash(Encoding.UTF8.GetBytes(s));
            return BytesToHex(b);
        }

        // HMAC(serverSeed, clientSeed|eventId|nonce)
        public static string HmacSha256Hex(string serverSeed, string clientSeed, string eventId, ulong nonce)
        {
            using var h = new HMACSHA256(Encoding.UTF8.GetBytes(serverSeed));
            var msg = $"{clientSeed}|{eventId}|{nonce}";
            var b = h.ComputeHash(Encoding.UTF8.GetBytes(msg));
            return BytesToHex(b);
        }

        public static double Rand01FromHex(string hex)
        {
            byte[] b = HexToBytes(hex);
            ulong x = 0;
            for (int i=0;i<8 && i<b.Length;i++) x = (x << 8) | b[i];
            return x / (double)ulong.MaxValue;
        }

        public static void VerifyCommit(string serverSeed, string expectedHash)
        {
            var h = Sha256Hex(serverSeed);
            if (!StringComparer.OrdinalIgnoreCase.Equals(h, expectedHash))
                throw new Exception("serverSeedHash mismatch");
        }

        private static string BytesToHex(byte[] b)
        {
            var sb = new StringBuilder(b.Length*2);
            for (int i=0;i<b.Length;i++) sb.Append(b[i].ToString("x2"));
            return sb.ToString();
        }

        private static byte[] HexToBytes(string hex)
        {
            int len = hex.Length/2;
            var b = new byte[len];
            for (int i=0;i<len;i++) b[i] = Convert.ToByte(hex.Substring(i*2,2),16);
            return b;
        }
    }
}
