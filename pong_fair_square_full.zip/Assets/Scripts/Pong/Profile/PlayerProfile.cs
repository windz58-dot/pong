using System;
using UnityEngine;

namespace Pong.Profile
{
    [Serializable]
    public sealed class PlayerProfile
    {
        public string playerId;
        public int credits;
        public int paidAttempts;
        public long lastDailyResetUtc;
        public int freeAttemptsRemaining;

        public static PlayerProfile LoadOrCreate()
        {
            var json = PlayerPrefs.GetString("PONG_PROFILE", "");
            if (!string.IsNullOrEmpty(json))
            {
                try { return JsonUtility.FromJson<PlayerProfile>(json); } catch {}
            }
            var p = new PlayerProfile
            {
                playerId = Guid.NewGuid().ToString("N"),
                credits = 250,
                paidAttempts = 0,
                lastDailyResetUtc = DateTimeOffset.UtcNow.ToUnixTimeSeconds(),
                freeAttemptsRemaining = 3
            };
            p.Save();
            return p;
        }

        public void Save()
        {
            PlayerPrefs.SetString("PONG_PROFILE", JsonUtility.ToJson(this));
            PlayerPrefs.Save();
        }

        public void DailyResetIfNeeded(int freePerDay)
        {
            var now = DateTimeOffset.UtcNow;
            var last = DateTimeOffset.FromUnixTimeSeconds(lastDailyResetUtc);
            if (now.UtcDateTime.Date != last.UtcDateTime.Date)
            {
                freeAttemptsRemaining = freePerDay;
                lastDailyResetUtc = now.ToUnixTimeSeconds();
                Save();
            }
        }
    }
}
