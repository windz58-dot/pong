using Pong.Profile;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace Pong.UI
{
    public sealed class MainMenuController : MonoBehaviour
    {
        [SerializeField] private TMP_Text creditsText;
        [SerializeField] private TMP_Text attemptsText;
        [SerializeField] private TMP_Text rankText;

        [SerializeField] private Button playButton;

        private PlayerProfile _profile;

        private void Awake()
        {
            _profile = PlayerProfile.LoadOrCreate();
            Refresh();
            if (playButton) playButton.onClick.AddListener(() => SceneManager.LoadScene("Gameplay"));
            Pong.Audio.AudioManager.I?.TransitionToMenu();
        }

        private void OnEnable() => Refresh();

        private void Refresh()
        {
            _profile.DailyResetIfNeeded(Common.PongConfig.Data.economy.freeAttemptsPerDay);
            if (creditsText) creditsText.text = _profile.credits.ToString();
            if (attemptsText) attemptsText.text = $"{_profile.freeAttemptsRemaining} free / {_profile.paidAttempts} paid";
            if (rankText) rankText.text = "Bronze I";
        }
    }
}
