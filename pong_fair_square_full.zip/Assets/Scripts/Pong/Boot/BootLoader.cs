using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Pong.Boot
{
    public sealed class BootLoader : MonoBehaviour
    {
        [SerializeField] private LoadingScreenController loadingUI;
        [SerializeField] private float fakeLoadSeconds = 1.6f;

        private void Start()
        {
            Application.targetFrameRate = 60;
            StartCoroutine(LoadFlow());
        }

        private IEnumerator LoadFlow()
        {
            float t = 0f;
            while (t < fakeLoadSeconds)
            {
                t += Time.unscaledDeltaTime;
                loadingUI?.SetProgress(t / fakeLoadSeconds * 0.85f);
                yield return null;
            }

            var op = SceneManager.LoadSceneAsync("MainMenu", LoadSceneMode.Single);
            op.allowSceneActivation = false;

            while (op.progress < 0.9f)
            {
                loadingUI?.SetProgress(0.85f + op.progress * 0.15f);
                yield return null;
            }

            loadingUI?.SetProgress(1f);
            yield return new WaitForSecondsRealtime(0.15f);
            op.allowSceneActivation = true;
        }
    }
}
