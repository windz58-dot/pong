package reward

import "math"

type RiskInputs struct {
	AccountAgeDays        float64
	AttemptsPerMinute     float64
	WinRate7d             float64
	DeviceUniqueness      float64
	IpEntropy             float64
	ShotPhysicsAnomaly    float64
	ChargebackRisk        float64
}

type RiskResult struct {
	RiskScore float64 `json:"risk_score"`
	HighRisk  bool    `json:"high_risk"`
}

func clamp01(x float64) float64 {
	if x < 0 { return 0 }
	if x > 1 { return 1 }
	return x
}

func ScoreRisk(in RiskInputs) RiskResult {
	A := clamp01(1 - math.Min(in.AccountAgeDays, 30)/30)
	B := clamp01((in.AttemptsPerMinute - 0.6)/2.0)
	C := clamp01((in.WinRate7d - 0.02)/0.10)
	D := clamp01((in.DeviceUniqueness - 2)/8)
	E := clamp01((in.IpEntropy - 3)/12)
	F := clamp01(in.ShotPhysicsAnomaly)
	G := clamp01(in.ChargebackRisk)

	score := 100 * (0.18*A + 0.16*B + 0.14*C + 0.12*D + 0.10*E + 0.22*F + 0.08*G)
	high := (score >= 70) || (F >= 0.85)
	return RiskResult{RiskScore: score, HighRisk: high}
}
