package reward

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"math"
	"sort"
)

type Config struct {
	Version     string `json:"version"`
	GeneratedAt string `json:"generatedAt"`
	Rules       Rules  `json:"rules"`
	Tables      Tables `json:"tables"`
	Signature   Sig    `json:"signature"`
}

type Rules struct {
	Crypto CryptoRules `json:"crypto"`
	Caps   Caps        `json:"caps"`
	EV     EVRules     `json:"ev"`
}

type CryptoRules struct {
	Enabled           bool               `json:"enabled"`
	WheelUnlockBase   float64            `json:"wheelUnlockBase"`
	WheelCryptoSegment float64           `json:"wheelCryptoSegment"`
	CryptoSplit       map[string]float64 `json:"cryptoSplit"`
}

type Caps struct {
	KillSwitch        bool    `json:"killSwitch"`
	MaxPiPerDay       float64 `json:"maxPiPerDay"`
	MaxPiPerMonth     float64 `json:"maxPiPerMonth"`
	MaxPiPerUserMonth float64 `json:"maxPiPerUserMonth"`
	UserCooldownHours float64 `json:"userCooldownHours"`
}

type EVRules struct {
	AttemptPriceUsd float64 `json:"attemptPriceUsd"`
	PayoutRatioMax  float64 `json:"payoutRatioMax"`
	PiUsdRef        float64 `json:"piUsdRef"`
}

type Tables struct {
	Wheel any `json:"wheel"`
	Pots  any `json:"pots"`
	// plus dynamic tables in config
	Raw map[string]json.RawMessage `json:"-"`
}

type Sig struct {
	Alg       string `json:"alg"`
	KeyId     string `json:"keyId"`
	Value     string `json:"value"`
	ConfigHash string `json:"configHash"`
}

// RewardEntry is the normalized output
type RewardEntry struct {
	ID      string  `json:"id"`
	Type    string  `json:"type"`
	Amount  float64 `json:"amount"`
	Display string  `json:"display"`
}

// CanonicalHash computes sha256 of canonical JSON over {version,generatedAt,rules,tables}.
func CanonicalHash(cfg *Config) (string, error) {
	// Marshal a map with stable key ordering by sorting keys.
	m := map[string]any{
		"version":     cfg.Version,
		"generatedAt": cfg.GeneratedAt,
		"rules":       cfg.Rules,
		"tables":      cfg.Tables,
	}
	b, err := CanonicalJSON(m)
	if err != nil {
		return "", err
	}
	sum := sha256.Sum256(b)
	return hex.EncodeToString(sum[:]), nil
}

func VerifySignature(cfg *Config, secret []byte) error {
	h, err := CanonicalHash(cfg)
	if err != nil {
		return err
	}
	if h != cfg.Signature.ConfigHash {
		return errors.New("configHash mismatch")
	}
	mac := hmac.New(sha256.New, secret)
	mac.Write([]byte(h))
	expected := hex.EncodeToString(mac.Sum(nil))
	if !hmac.Equal([]byte(expected), []byte(cfg.Signature.Value)) {
		return errors.New("signature invalid")
	}
	return nil
}

func HMACRandHex(serverSeed []byte, clientSeed string, nonce uint64, eventId string) string {
	mac := hmac.New(sha256.New, serverSeed)
	mac.Write([]byte(clientSeed))
	mac.Write([]byte("|"))
	mac.Write([]byte(eventId))
	mac.Write([]byte("|"))
	// nonce
	var nb [8]byte
	for i := 0; i < 8; i++ {
		nb[7-i] = byte(nonce >> (8 * i))
	}
	mac.Write(nb[:])
	return hex.EncodeToString(mac.Sum(nil))
}

// Rand01 converts hex to [0,1).
func Rand01(hexStr string) float64 {
	b, _ := hex.DecodeString(hexStr)
	// use first 8 bytes
	var x uint64
	for i := 0; i < 8 && i < len(b); i++ {
		x = (x << 8) | uint64(b[i])
	}
	return float64(x) / float64(math.MaxUint64)
}

// WeightedPick picks entry by weight.
func WeightedPick(entries []RewardEntry, r01 float64) (RewardEntry, error) {
	var total float64
	for _, e := range entries {
		if e.Amount < 0 || e.Weight() < 0 {
			continue
		}
		total += e.Weight()
	}
	if total <= 0 {
		return RewardEntry{}, errors.New("no entries")
	}
	target := r01 * total
	var acc float64
	for _, e := range entries {
		acc += e.Weight()
		if target <= acc {
			return e, nil
		}
	}
	return entries[len(entries)-1], nil
}

func (e RewardEntry) Weight() float64 { return 1 } // placeholder if you normalize

// CanonicalJSON: stable JSON with sorted map keys.
func CanonicalJSON(v any) ([]byte, error) {
	switch t := v.(type) {
	case map[string]any:
		keys := make([]string, 0, len(t))
		for k := range t { keys = append(keys, k) }
		sort.Strings(keys)
		out := make(map[string]any, len(t))
		for _, k := range keys { out[k] = t[k] }
		return json.Marshal(out)
	default:
		return json.Marshal(v)
	}
}
