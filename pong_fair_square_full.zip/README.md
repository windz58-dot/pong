# PONG — Reward Engine Integration Patch (Server-authoritative + Telemetry + Missions + Anti-cheat)

This patch upgrades the playable Unity frontend to production flow:

✅ Replace local reward awarding with server-based commit→reveal:
- Commit before attempt
- Reveal after eligibility bucket known (pot/hole)
- Client verifies proof (serverSeedHash + HMAC rand)
- Apply reward locally ONLY after verification

✅ Fix performance + physics correctness:
- Remove per-frame FindObjectOfType
- Ensure rb.isKinematic reset is correct

✅ Add:
- Telemetry events (pluggable)
- Mission + streak system (credits/cosmetics only)
- Server anti-cheat plausibility checks (Go sample)

## Install
1) Import/merge this patch into your Unity project (copy `Assets/`).
2) Ensure you also imported:
   - `pong_production_reward_engine_pack.zip` (for API contracts + ProvableFairness)
   - `pong_unity_frontend_playable.zip`

## Unity Wiring (5 minutes)
Gameplay scene:
- Add `Pong.Telemetry.TelemetryHub` to a persistent object (or GameplayRoot)
- Add `Pong.Rewards.RewardService` to a persistent object (or GameplayRoot)
- In `GameplayBootstrap` inspector:
  - Assign `rewardService`
  - Assign `telemetryHub`
  - Assign `ui` and `ball` refs as usual

Optional:
- Add `Pong.Meta.MissionsManager` and `Pong.Meta.StreakManager` to MainMenu scene.

## Backend
Implements:
- POST /v1/reward/commit
- POST /v1/reward/reveal
See Go sample in `/Server/`.

