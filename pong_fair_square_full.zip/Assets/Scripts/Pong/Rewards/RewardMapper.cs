using Pong.Gameplay;

namespace Pong.Rewards
{
    public static class RewardMapper
    {
        // Applies only after verification.
        public static RewardResult ToLocal(RewardEntry e)
        {
            if (e == null) return RewardResult.Credits(10);

            return e.type switch
            {
                "CREDITS" => RewardResult.Credits((int)e.amount),
                "PAID_ATTEMPT" => RewardResult.PaidAttempt((int)e.amount),
                "COSMETIC" => RewardResult.Cosmetic(e.display.Replace("Cosmetic: ","")),
                // Crypto types should only come from verified server + caps; keep display generic.
                "CRYPTO_PI" => (e.amount >= 10) ? RewardResult.Pi10() : RewardResult.Pi1(),
                _ => RewardResult.Credits(10),
            };
        }
    }
}
