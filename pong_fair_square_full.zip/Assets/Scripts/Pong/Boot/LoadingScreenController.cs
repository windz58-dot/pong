using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Pong.Boot
{
    public sealed class LoadingScreenController : MonoBehaviour
    {
        [SerializeField] private Image progressFill;
        [SerializeField] private TMP_Text progressText;
        [SerializeField] private TMP_Text tipsText;
        [SerializeField] private LoadingTipsRotator tipsRotator;

        public void SetProgress(float p01)
        {
            p01 = Mathf.Clamp01(p01);
            if (progressFill) progressFill.fillAmount = p01;
            if (progressText) progressText.text = Mathf.RoundToInt(p01 * 100f) + "%";
        }

        private void Awake()
        {
            if (!tipsRotator) tipsRotator = GetComponentInChildren<LoadingTipsRotator>(true);
            if (tipsRotator && tipsText)
                tipsRotator.Configure(tipsText, Random.Range(1.4f, 2.2f), Random.Range(0.12f, 0.22f));
        }
    }
}
