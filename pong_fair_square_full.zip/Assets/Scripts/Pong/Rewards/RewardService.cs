using System;
using System.Collections;
using System.Collections.Generic;
using Pong.Net;
using Pong.Profile;
using Pong.Telemetry;
using UnityEngine;

namespace Pong.Rewards
{
    public sealed class RewardService : MonoBehaviour
    {
        public static RewardService I { get; private set; }

        [SerializeField] private BackendClient backendClient;
        [SerializeField] private bool dontDestroyOnLoad = true;
        [SerializeField] private bool allowOfflineFallback = true;

        private PendingCommit _pending;

        [Serializable]
        public sealed class PendingCommit
        {
            public string eventId;
            public string serverSeedHash;
            public string clientSeed;
            public ulong nonce;
            public string configVersion;
            public string configHash;
            public bool highRisk;
            public float riskScore;
        }

        private void Awake()
        {
            if (I && I != this) { Destroy(gameObject); return; }
            I = this;
            if (dontDestroyOnLoad) DontDestroyOnLoad(gameObject);
            if (!backendClient) backendClient = FindObjectOfType<BackendClient>();
        }

        public bool HasPending => _pending != null;

        public void CommitBeforeAttempt(string playerId, string sessionId, string mode, string build, string deviceId, Action<PendingCommit> onOk, Action<string> onErr)
        {
            var clientSeed = Guid.NewGuid().ToString("N") + UnityEngine.Random.Range(0, int.MaxValue).ToString();
            ulong nonce = (ulong)DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

            var req = new RewardCommitRequest
            {
                playerId = playerId,
                sessionId = sessionId,
                clientSeed = clientSeed,
                nonce = nonce,
                context = new RewardCommitRequest.Context { mode = mode, build = build, deviceId = deviceId }
            };

            string json = JsonUtility.ToJson(req);
            TelemetryHub.I?.Track("reward_commit_start");

            if (!backendClient)
            {
                if (allowOfflineFallback)
                {
                    _pending = new PendingCommit { eventId = "offline", serverSeedHash = "offline", clientSeed = clientSeed, nonce = nonce };
                    onOk?.Invoke(_pending);
                    return;
                }
                onErr?.Invoke("BackendClient missing");
                return;
            }

            StartCoroutine(backendClient.PostJson("/v1/reward/commit", json,
                ok =>
                {
                    var resp = JsonUtility.FromJson<RewardCommitResponse>(ok);
                    _pending = new PendingCommit
                    {
                        eventId = resp.eventId,
                        serverSeedHash = resp.serverSeedHash,
                        clientSeed = clientSeed,
                        nonce = nonce,
                        configVersion = resp.configVersion,
                        configHash = resp.configHash,
                        highRisk = resp.risk != null && resp.risk.high_risk,
                        riskScore = resp.risk != null ? resp.risk.risk_score : 0f
                    };
                    TelemetryHub.I?.Track("reward_commit_ok", new Dictionary<string, object>{{"high_risk", _pending.highRisk},{"risk_score", _pending.riskScore}});
                    onOk?.Invoke(_pending);
                },
                err =>
                {
                    TelemetryHub.I?.Track("reward_commit_err", new Dictionary<string, object>{{"err", err}});
                    if (allowOfflineFallback)
                    {
                        _pending = new PendingCommit { eventId = "offline", serverSeedHash = "offline", clientSeed = clientSeed, nonce = nonce };
                        onOk?.Invoke(_pending);
                    }
                    else onErr?.Invoke(err);
                }));
        }

        public void RevealAfterEligibility(string playerId, string bucket, int potIndex, bool wheelUnlocked, ShotTelemetry shot, Action<RewardRevealResponse> onOk, Action<string> onErr)
        {
            if (_pending == null)
            {
                onErr?.Invoke("No pending commit; call CommitBeforeAttempt first.");
                return;
            }

            // Offline fallback: NEVER allow crypto offline
            if (_pending.eventId == "offline")
            {
                var resp = OfflineFallback(bucket);
                _pending = null;
                onOk?.Invoke(resp);
                return;
            }

            var req = new RewardRevealRequest
            {
                playerId = playerId,
                eventId = _pending.eventId,
                bucket = bucket,
                eligibility = new RewardRevealRequest.Eligibility { potIndex = potIndex, wheelUnlocked = wheelUnlocked },
                shot = new RewardRevealRequest.Shot { power01 = shot.power01, flightSeconds = shot.flightSeconds, bounces = shot.bounces }
            };

            string json = JsonUtility.ToJson(req);
            TelemetryHub.I?.Track("reward_reveal_start", new Dictionary<string, object>{{"bucket", bucket},{"potIndex", potIndex}});

            StartCoroutine(backendClient.PostJson("/v1/reward/reveal", json,
                ok =>
                {
                    var resp = JsonUtility.FromJson<RewardRevealResponse>(ok);

                    try
                    {
                        // verify commit integrity
                        ProvableFairness.VerifyCommit(resp.serverSeed, resp.serverSeedHash);

                        // verify rand
                        string randHex = ProvableFairness.HmacSha256Hex(resp.serverSeed, _pending.clientSeed, resp.eventId, _pending.nonce);
                        if (!StringComparer.OrdinalIgnoreCase.Equals(randHex, resp.rand))
                            throw new Exception("rand proof mismatch");

                        // If high_risk, client can choose to hide crypto animations (server should block crypto anyway)
                        TelemetryHub.I?.Track("reward_reveal_ok", new Dictionary<string, object>{{"reward", resp.reward.display},{"high_risk", resp.risk.high_risk}});
                        _pending = null;
                        onOk?.Invoke(resp);
                    }
                    catch (Exception ex)
                    {
                        TelemetryHub.I?.Track("reward_reveal_verify_fail", new Dictionary<string, object>{{"ex", ex.Message}});
                        onErr?.Invoke("Verification failed: " + ex.Message);
                    }
                },
                err =>
                {
                    TelemetryHub.I?.Track("reward_reveal_err", new Dictionary<string, object>{{"err", err}});
                    if (allowOfflineFallback)
                    {
                        var resp = OfflineFallback(bucket);
                        _pending = null;
                        onOk?.Invoke(resp);
                    }
                    else onErr?.Invoke(err);
                }));
        }

        private RewardRevealResponse OfflineFallback(string bucket)
        {
            // Offline safe rewards only (credits/attempts/cosmetics), never crypto.
            RewardEntry r = new RewardEntry { id="offline_credits", type="CREDITS", amount=15, display="+15 Credits" };
            if (bucket == "UTILITY") r = new RewardEntry { id="offline_attempt", type="PAID_ATTEMPT", amount=1, display="+1 Extra Attempt" };

            return new RewardRevealResponse
            {
                auditId = "offline",
                eventId = "offline",
                serverSeed = "offline",
                serverSeedHash = "offline",
                clientSeed = "offline",
                nonce = 0,
                rand = "offline",
                reward = r,
                capsApplied = new CapsApplied { killSwitch=false, userCooldownBlocked=false, budgetBlocked=false, evBlocked=false },
                risk = new RiskResult { risk_score = 0, high_risk = false }
            };
        }
    }

    [Serializable]
    public sealed class ShotTelemetry
    {
        public float power01;
        public float flightSeconds;
        public int bounces;
        public float maxSpeed;
    }
}
