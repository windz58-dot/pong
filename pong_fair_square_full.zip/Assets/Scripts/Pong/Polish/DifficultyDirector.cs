using System;
using UnityEngine;

namespace Pong.Polish
{
    [Serializable]
    public sealed class DifficultyProfile
    {
        [Range(0.7f, 1.6f)] public float holeRadiusMultiplier = 1.0f;
        [Range(0.8f, 1.4f)] public float frictionMultiplier = 1.0f;
        [Range(0.0f, 0.5f)] public float obstacleSpeedBonus = 0.0f;
    }

    public sealed class DifficultyDirector : MonoBehaviour
    {
        [Header("Pot Layout")]
        [SerializeField] private Transform[] potSlots; // assign 6 transforms in scene (slot positions)
        [SerializeField] private Transform[] potObjects; // actual pot triggers/meshes (6)
        [SerializeField] private bool perUserDailyShuffle = true;

        [Header("Adaptive")]
        [SerializeField] private float skillEma = 0.0f; // 0..1
        [SerializeField] private float emaAlpha = 0.12f; // how quickly skill updates
        [SerializeField] private DifficultyProfile easy = new DifficultyProfile { holeRadiusMultiplier=1.15f, frictionMultiplier=1.05f, obstacleSpeedBonus=0.0f };
        [SerializeField] private DifficultyProfile mid  = new DifficultyProfile { holeRadiusMultiplier=1.0f,  frictionMultiplier=1.0f,  obstacleSpeedBonus=0.08f };
        [SerializeField] private DifficultyProfile hard = new DifficultyProfile { holeRadiusMultiplier=0.85f, frictionMultiplier=0.95f, obstacleSpeedBonus=0.18f };

        [Header("Targets")]
        [SerializeField] private SphereCollider holeCollider; // optional
        [SerializeField] private PhysicMaterial ballMaterial; // optional

        private void Start()
        {
            if (perUserDailyShuffle) ShufflePotsDaily();
            ApplyDifficulty(ComputeProfile());
        }

        public void ReportAttempt(bool success, float shotQuality01)
        {
            // success + quality increases skill; misses reduce slightly
            float sample = success ? Mathf.Lerp(0.55f, 1f, shotQuality01) : Mathf.Lerp(0.0f, 0.35f, shotQuality01);
            skillEma = Mathf.Lerp(skillEma, sample, emaAlpha);
            ApplyDifficulty(ComputeProfile());
        }

        private DifficultyProfile ComputeProfile()
        {
            // smooth blend: easy->mid->hard
            if (skillEma < 0.35f) return Lerp(easy, mid, skillEma / 0.35f);
            return Lerp(mid, hard, Mathf.Clamp01((skillEma - 0.35f) / 0.65f));
        }

        private void ApplyDifficulty(DifficultyProfile p)
        {
            if (holeCollider) holeCollider.radius = Mathf.Clamp(holeCollider.radius * p.holeRadiusMultiplier, 0.02f, 0.25f);
            if (ballMaterial)
            {
                ballMaterial.dynamicFriction = Mathf.Clamp01(ballMaterial.dynamicFriction * p.frictionMultiplier);
                ballMaterial.staticFriction  = Mathf.Clamp01(ballMaterial.staticFriction  * p.frictionMultiplier);
            }

            // obstacleSpeedBonus is a hook: your obstacle scripts can read it from this director if present
            // e.g., SpinnerController.SetSpeedBase( baseSpeed * (1 + obstacleSpeedBonus) )
        }

        private DifficultyProfile Lerp(DifficultyProfile a, DifficultyProfile b, float t)
        {
            return new DifficultyProfile
            {
                holeRadiusMultiplier = Mathf.Lerp(a.holeRadiusMultiplier, b.holeRadiusMultiplier, t),
                frictionMultiplier = Mathf.Lerp(a.frictionMultiplier, b.frictionMultiplier, t),
                obstacleSpeedBonus = Mathf.Lerp(a.obstacleSpeedBonus, b.obstacleSpeedBonus, t),
            };
        }

        private void ShufflePotsDaily()
        {
            if (potSlots == null || potSlots.Length < 6 || potObjects == null || potObjects.Length < 6)
                return;

            // Deterministic per-user per-day permutation (feels fair; hard to memorize globally)
            var userId = PlayerPrefs.GetString("PONG_PLAYER_ID", "anon");
            if (string.IsNullOrEmpty(userId))
            {
                userId = Guid.NewGuid().ToString("N");
                PlayerPrefs.SetString("PONG_PLAYER_ID", userId);
            }

            var day = DateTime.UtcNow.Date.ToString("yyyyMMdd");
            int seed = StableHash(userId + "|" + day + "|PONG_SALT_v1");
            var rng = new System.Random(seed);

            // Fisher-Yates on indices
            int[] idx = { 0,1,2,3,4,5 };
            for (int i = idx.Length - 1; i > 0; i--)
            {
                int j = rng.Next(i + 1);
                (idx[i], idx[j]) = (idx[j], idx[i]);
            }

            // Move pot objects to slots
            for (int i=0;i<6;i++)
            {
                var pot = potObjects[i];
                var slot = potSlots[idx[i]];
                if (pot && slot)
                {
                    pot.position = slot.position;
                    pot.rotation = slot.rotation;
                }
            }
        }

        private static int StableHash(string s)
        {
            unchecked
            {
                int h = 23;
                for (int i=0;i<s.Length;i++)
                    h = h * 31 + s[i];
                return h;
            }
        }
    }
}
