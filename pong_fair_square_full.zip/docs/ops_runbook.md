# Ops Runbook (Rewards)

## Kill Switch
Set rules.caps.killSwitch = true in reward config and deploy.
Behavior: crypto + rare drops disabled, fallback to credits/attempts.

## Budget Caps
- maxPiPerDay / maxPiPerMonth / maxPiPerUserMonth are enforced at reveal time.
- If cap hit => convert to non-crypto fallback (credits).

## Versioning
- Each config release increments version vN.
- Store configHash + signature in backend and return them in commit response.
- Client can pin allowed configHash list per build (optional) to prevent silent changes.

## Auditing
Store audit record per reveal:
- auditId, eventId, playerId, serverSeedHash, serverSeed (encrypted at rest), clientSeed, nonce,
  bucket, reward, capsApplied, risk_score

## Fraud Handling
- high_risk => block crypto, throttle rare cosmetics.
- risk_score >= 85 => leaderboard submissions shadow-restricted.

