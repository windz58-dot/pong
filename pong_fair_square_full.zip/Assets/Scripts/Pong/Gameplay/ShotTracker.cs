using UnityEngine;

namespace Pong.Gameplay
{
    // Tracks per-attempt telemetry for anti-cheat + missions (server plausibility).
    // Attach to GameplayRoot or Ball. It auto-binds to BallController and AimStrikeController.
    public sealed class ShotTracker : MonoBehaviour
    {
        [SerializeField] private BallController ball;
        [SerializeField] private AimStrikeController aim;

        private float _shotStartTime;
        private float _power01;
        private int _bounces;
        private float _maxSpeed;
        private bool _inFlight;

        public float Power01 => _power01;
        public float FlightSeconds => _inFlight ? (Time.time - _shotStartTime) : Mathf.Max(0, Time.time - _shotStartTime);
        public int Bounces => _bounces;
        public float MaxSpeed => _maxSpeed;

        private void Awake()
        {
            if (!ball) ball = FindObjectOfType<BallController>();
            if (!aim) aim = FindObjectOfType<AimStrikeController>();
        }

        private void OnEnable()
        {
            ResetAttempt();
        }

        public void ResetAttempt()
        {
            _power01 = 0f;
            _bounces = 0;
            _maxSpeed = 0f;
            _inFlight = false;
            _shotStartTime = Time.time;
        }

        public void OnStrike(float power01)
        {
            _power01 = Mathf.Clamp01(power01);
            _bounces = 0;
            _maxSpeed = 0f;
            _inFlight = true;
            _shotStartTime = Time.time;
        }

        public void OnPhysicsContact()
        {
            if (_inFlight) _bounces++;
        }

        private void FixedUpdate()
        {
            if (!ball) return;
            var rb = ball.RB;
            if (!rb) return;
            _maxSpeed = Mathf.Max(_maxSpeed, rb.velocity.magnitude);

            // If ball has been scored or stopped, consider flight ended.
            if (!ball.CanStrike) return; // still in shot
            // If CanStrike becomes true after stop logic, flight ends.
            if (_inFlight) _inFlight = false;
        }
    }
}
