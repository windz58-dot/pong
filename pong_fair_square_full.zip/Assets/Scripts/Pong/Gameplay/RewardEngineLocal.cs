using UnityEngine;

namespace Pong.Gameplay
{
    public static class RewardEngineLocal
    {
        public static RewardResult RollForPot(int potIndex)
        {
            switch (potIndex)
            {
                case 0: return RollRareDirectCrypto(true) ? RewardResult.Pi10() : RewardResult.Credits(40);
                case 1: return RollRareDirectCrypto(false) ? RewardResult.Pi1() : RewardResult.Credits(25);
                case 2: return RewardResult.WheelSpin();
                case 3: return RewardResult.Credits(Random.Range(10, 26));
                case 4: return RewardResult.Cosmetic("Neon Grip (Rare)");
                case 5: return RewardResult.PaidAttempt(1);
                default: return RewardResult.Credits(5);
            }
        }

        // Wheel crypto chance total = 1%, then 90/10 split.
        public static RewardResult RollWheel()
        {
            float r = Random.value;
            if (r < 0.01f)
            {
                float c = Random.value;
                return (c < 0.9f) ? RewardResult.Pi1() : RewardResult.Pi10();
            }
            if (r < 0.11f) return RewardResult.Credits(Random.Range(40, 81));
            if (r < 0.31f) return RewardResult.PaidAttempt(1);
            return RewardResult.Cosmetic("Aurora Frame (Epic)");
        }

        private static bool RollRareDirectCrypto(bool tenPi)
        {
            float p = tenPi ? 0.0001f : 0.0005f; // 0.01% / 0.05%
            return Random.value < p;
        }
    }
}
