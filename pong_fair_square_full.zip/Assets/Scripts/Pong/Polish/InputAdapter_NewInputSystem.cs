#if ENABLE_INPUT_SYSTEM
using UnityEngine;
using UnityEngine.InputSystem;

namespace Pong.Polish
{
    // Optional helper: provides normalized pointer position for aim/parallax, etc.
    public sealed class InputAdapter_NewInputSystem : MonoBehaviour
    {
        public static Vector2 PointerPosition()
        {
            if (Pointer.current != null) return Pointer.current.position.ReadValue();
            return Mouse.current != null ? Mouse.current.position.ReadValue() : Vector2.zero;
        }
    }
}
#endif
