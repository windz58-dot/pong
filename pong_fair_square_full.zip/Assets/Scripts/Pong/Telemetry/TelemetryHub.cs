using System;
using System.Collections.Generic;
using UnityEngine;

namespace Pong.Telemetry
{
    public interface ITelemetrySink
    {
        void Track(string eventName, Dictionary<string, object> props = null);
    }

    // Default sink: logs to Console (safe, no SDK required)
    public sealed class DebugTelemetrySink : ITelemetrySink
    {
        public void Track(string eventName, Dictionary<string, object> props = null)
        {
            if (props == null) { Debug.Log($"[Telemetry] {eventName}"); return; }
            Debug.Log($"[Telemetry] {eventName} :: {MiniJson(props)}");
        }

        private static string MiniJson(Dictionary<string, object> d)
        {
            try { return JsonUtility.ToJson(new Wrapper{ d = d }); }
            catch { return "(props)"; }
        }
        [Serializable] private sealed class Wrapper { public Dictionary<string, object> d; }
    }

    public sealed class TelemetryHub : MonoBehaviour
    {
        public static TelemetryHub I { get; private set; }

        [SerializeField] private bool dontDestroyOnLoad = true;
        private ITelemetrySink _sink = new DebugTelemetrySink();

        private void Awake()
        {
            if (I && I != this) { Destroy(gameObject); return; }
            I = this;
            if (dontDestroyOnLoad) DontDestroyOnLoad(gameObject);
        }

        public void SetSink(ITelemetrySink sink) => _sink = sink ?? new DebugTelemetrySink();

        public void Track(string name, Dictionary<string, object> props = null) => _sink.Track(name, props);
    }
}
