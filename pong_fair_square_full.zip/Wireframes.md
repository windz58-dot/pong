# UI Wireframes (UGUI)

BOOT
Canvas -> Panel
- ProgressBar (Image Filled)
- ProgressText (TMP)
- LoadingTipsText (TMP)
Attach LoadingScreenController to Panel.

MAIN MENU
Canvas -> TopBar (Credits TMP, Attempts TMP, Rank TMP)
Buttons: Play, Store, Leaderboard, TrustCommunity
Attach MainMenuController.

GAMEPLAY
Canvas -> HUD (Attempts TMP, Speed TMP, PowerBar Image, PowerText TMP)
ResultPanel (hidden): Title TMP, Reward TMP, PlayAgain Button, Back Button
Attach GameplayUIController.
