using Pong.Rewards;
using UnityEngine;

namespace Pong.Gameplay
{
    [RequireComponent(typeof(Collider))]
    public sealed class PotTrigger : MonoBehaviour
    {
        [Range(0,5)] public int potIndex;
        [SerializeField] private string bucket = "CREDITS"; // set per pot; WHEEL_UNLOCK for wheel pot

        private void Reset()
        {
            var c = GetComponent<Collider>();
            c.isTrigger = true;
        }

        private void OnTriggerEnter(Collider other)
        {
            var ball = other.GetComponent<BallController>();
            if (!ball) return;

            // Eligibility known now -> reveal
            var shot = GameplayShotSampler.Sample(ball);
            RewardService.I.RevealAfterEligibility(
                playerId: Pong.Profile.PlayerProfile.LoadOrCreate().playerId,
                bucket: bucket,
                potIndex: potIndex,
                wheelUnlocked: bucket == "WHEEL_UNLOCK",
                shot: shot,
                onOk: resp =>
                {
                    var reward = RewardMapper.ToLocal(resp.reward);
                    ball.Score(reward);
                },
                onErr: err =>
                {
                    // fallback: safe credits only handled inside RewardService when offline allowed.
                    Debug.LogError("Reveal failed: " + err);
                    ball.Score(RewardResult.Credits(10));
                });
        }
    }
}
