using Pong.Profile;
using Pong.Rewards;
using Pong.Telemetry;
using UnityEngine;

namespace Pong.Gameplay
{
    public sealed class GameplayBootstrap : MonoBehaviour
    {
        [SerializeField] private BallController ball;
        [SerializeField] private AimStrikeController aim;
        [SerializeField] private GameplayUIController ui;

        [Header("Telemetry")]
        [SerializeField] private ShotTracker shotTracker;

        [Header("Services")]
        [SerializeField] private RewardService rewardService;
        [SerializeField] private TelemetryHub telemetryHub;

        private PlayerProfile _profile;
        private string _sessionId;

        private void Awake()
        {
            _profile = PlayerProfile.LoadOrCreate();
            _profile.DailyResetIfNeeded(Common.PongConfig.Data.economy.freeAttemptsPerDay);

            if (!telemetryHub) telemetryHub = TelemetryHub.I;
            if (!rewardService) rewardService = RewardService.I;

            ui?.Bind(_profile);

            if (ball)
            {
                ball.SetUI(ui);
                ball.OnStopped += HandleBallStopped;
                ball.OnScored += HandleScored;
            }

            aim?.Bind(ball);

            if (!shotTracker) shotTracker = FindObjectOfType<ShotTracker>();

            _sessionId = System.Guid.NewGuid().ToString("N");
        }

        private void Start() => StartAttemptOrEnd();

        private void StartAttemptOrEnd()
{
    // Decide attempt mode BEFORE consumption (free attempts are decremented in TryConsumeAttempt).
    string mode = (_profile.freeAttemptsRemaining > 0) ? "daily" : "paid";

    if (!AttemptBank.TryConsumeAttempt(_profile))
    {
        ui?.ShowOutOfAttempts();
        return;
    }

    telemetryHub?.Track("attempt_start");
    Pong.Meta.MissionsManager.I?.ReportPlayAttempt();

    shotTracker?.ResetAttempt();

    // Commit BEFORE attempt
    rewardService.CommitBeforeAttempt(
        playerId: _profile.playerId,
        sessionId: _sessionId,
        mode: mode,
        build: Application.version,
        deviceId: SystemInfo.deviceUniqueIdentifier,
        onOk: _ => { /* ready */ },
        onErr: err => Debug.LogWarning("Commit failed: " + err)
    );

    ui?.OnAttemptStarted(_profile);
    ball?.ResetBall();
    aim?.EnableInput(true);
}


            telemetryHub?.Track("attempt_start");
            Pong.Meta.MissionsManager.I?.ReportPlayAttempt();

            // Commit BEFORE attempt
            rewardService.CommitBeforeAttempt(
                playerId: _profile.playerId,
                sessionId: _sessionId,
                mode: (_profile.freeAttemptsRemaining > 0) ? "daily" : "paid",
                build: Application.version,
                deviceId: SystemInfo.deviceUniqueIdentifier,
                onOk: _ => { /* ready */ },
                onErr: err => Debug.LogWarning("Commit failed: " + err)
            );

            ui?.OnAttemptStarted(_profile);
            ball?.ResetBall();
            aim?.EnableInput(true);
        }

        private void HandleBallStopped()
        {
            aim?.EnableInput(false);
            telemetryHub?.Track("attempt_miss");
            ui?.ShowMiss(() => StartAttemptOrEnd());
        }

        private void HandleScored(RewardResult reward)
        {
            aim?.EnableInput(false);
            telemetryHub?.Track("attempt_score");
            Pong.Meta.MissionsManager.I?.ReportScore();
            ui?.ShowReward(reward, _profile, () => StartAttemptOrEnd());
        }
    }
}
