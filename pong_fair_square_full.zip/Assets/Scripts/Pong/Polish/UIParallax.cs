using UnityEngine;

namespace Pong.Polish
{
    public sealed class UIParallax : MonoBehaviour
    {
        [SerializeField] private RectTransform[] layers;
        [SerializeField] private float maxOffset = 10f;
        [SerializeField] private float smooth = 10f;

        private Vector2 _target;
        private Vector2 _cur;

        private void Update()
        {
            // Mouse/touch to subtle parallax; cheap and premium.
            var p = Input.mousePosition;
            var nx = (p.x / Screen.width) * 2f - 1f;
            var ny = (p.y / Screen.height) * 2f - 1f;
            _target = new Vector2(nx, ny) * maxOffset;

            _cur = Vector2.Lerp(_cur, _target, 1f - Mathf.Exp(-smooth * Time.unscaledDeltaTime));

            for (int i=0;i<layers.Length;i++)
            {
                if (!layers[i]) continue;
                float k = (i+1f) / layers.Length;
                layers[i].anchoredPosition = _cur * k;
            }
        }
    }
}
