using Pong.Common;
using UnityEngine;

namespace Pong.Gameplay
{
    public sealed class AimStrikeController : MonoBehaviour
    {
        [SerializeField] private Camera cam;
        [SerializeField] private Transform racketPoint;
        [SerializeField] private GameplayUIController ui;

        [SerializeField] private float aimPlaneY = 0.0f;
        [SerializeField] private float minPower = 0.08f;

        private BallController _ball;
        private bool _enabled;
        private bool _charging;
        private float _power01;
        private Vector3 _aimDir = Vector3.forward;

        public event System.Action<float> OnStrikePower;
        public event System.Action<Vector3,float> OnCharging;

        public void Bind(BallController ball) => _ball = ball;

        public void EnableInput(bool on)
        {
            _enabled = on;
            _charging = false;
            _power01 = 0f;
            ui?.SetPower(0f);
        }

        private void Awake() { if (!cam) cam = Camera.main; }

        private void Update()
        {
            if (!_enabled || !_ball || !_ball.CanStrike) return;

            UpdateAim();

            bool down = Input.GetMouseButtonDown(0);
            bool held = Input.GetMouseButton(0);
            bool up = Input.GetMouseButtonUp(0);

            if (down) { _charging = true; _power01 = 0f; Pong.Audio.AudioManager.I?.SfxWhoosh(0.12f); }

            if (_charging && held)
            {
                _power01 = Mathf.Clamp01(_power01 + Time.unscaledDeltaTime * 0.65f);
                ui?.SetPower(_power01);
                OnCharging?.Invoke(_aimDir, _power01);
            }

            if (_charging && up)
            {
                _charging = false;
                float p = Mathf.Max(minPower, _power01);
                OnStrikePower?.Invoke(p);
                Strike(p);
                _power01 = 0f;
                ui?.SetPower(0f);
            }
        }

        private void UpdateAim()
        {
            if (!cam) return;
            var ray = cam.ScreenPointToRay(Input.mousePosition);
            var plane = new Plane(Vector3.up, new Vector3(0, aimPlaneY, 0));
            if (plane.Raycast(ray, out float enter))
            {
                var hit = ray.GetPoint(enter);
                var from = _ball.transform.position;
                _aimDir = hit - from; _aimDir.y = 0;
                if (_aimDir.sqrMagnitude > 0.001f) _aimDir.Normalize();

                if (racketPoint)
                {
                    racketPoint.position = from + _aimDir * 0.18f + Vector3.up * 0.02f;
                    racketPoint.rotation = Quaternion.LookRotation(_aimDir, Vector3.up);
                }
            }
        }

        private void Strike(float power01)
        {
            float gamma = PongConfig.Data.economy.powerCurveGamma;
            float curved = Mathf.Pow(Mathf.Clamp01(power01), gamma);
            float maxImpulse = PongConfig.Data.economy.maxImpulse;
            float impulseMag = maxImpulse * curved;
            _ball.Strike(_aimDir, impulseMag, PongConfig.Data.economy.spinFriction);
        }
    }
}
