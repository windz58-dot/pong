using System.Collections;
using Pong.Gameplay;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Pong.Polish
{
    public sealed class WheelFlowController : MonoBehaviour
    {
        [Header("UI")]
        [SerializeField] private GameObject root;
        [SerializeField] private Button spinButton;
        [SerializeField] private RectTransform wheel;
        [SerializeField] private TMP_Text resultText;

        [Header("Spin")]
        [SerializeField] private float spinSeconds = 1.35f;
        [SerializeField] private float extraRotations = 6.5f;
        [SerializeField] private AnimationCurve ease = AnimationCurve.EaseInOut(0,0,1,1);

        private bool _busy;

        private void Awake()
        {
            if (root) root.SetActive(false);
            if (spinButton) spinButton.onClick.AddListener(() => { if(!_busy) StartCoroutine(Spin()); });
        }

        public void Open()
        {
            if (root) root.SetActive(true);
            if (resultText) resultText.text = "Spin to reveal…";
        }

        public void Close()
        {
            if (root) root.SetActive(false);
        }

        private IEnumerator Spin()
        {
            _busy = true;
            spinButton.interactable = false;

            // TODO: backend hook (commit-reveal). For now: local roll
            RewardResult reward = RewardEngineLocal.RollWheel();

            // Map reward to a target angle for satisfying reveal (cosmetic; does not change outcome)
            float targetAngle = TargetAngleForReward(reward.type);
            float start = wheel ? wheel.localEulerAngles.z : 0f;
            float end = start + 360f * extraRotations + targetAngle;

            float t = 0f;
            while (t < 1f)
            {
                t += Time.unscaledDeltaTime / Mathf.Max(0.01f, spinSeconds);
                float k = ease.Evaluate(Mathf.Clamp01(t));
                if (wheel)
                {
                    var e = wheel.localEulerAngles;
                    e.z = Mathf.LerpAngle(start, end, k);
                    wheel.localEulerAngles = e;
                }
                yield return null;
            }

            if (resultText) resultText.text = reward.DisplayText;
            Pong.Audio.AudioManager.I?.SfxSuccess(0.45f);

            yield return new WaitForSecondsRealtime(0.55f);
            spinButton.interactable = true;
            _busy = false;
        }

        private float TargetAngleForReward(RewardType type)
        {
            // 8 segments example; update to match your wheel art
            // Angles are cosmetic; outcome already decided.
            switch (type)
            {
                case RewardType.CryptoPi10: return 15f;
                case RewardType.CryptoPi1:  return 60f;
                case RewardType.PaidAttempt:return 135f;
                case RewardType.Credits:    return 210f;
                default:                   return 300f;
            }
        }
    }
}
