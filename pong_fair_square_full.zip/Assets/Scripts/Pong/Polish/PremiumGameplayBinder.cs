using Pong.Common;
using Pong.Gameplay;
using UnityEngine;

namespace Pong.Polish
{
    public sealed class PremiumGameplayBinder : MonoBehaviour
    {
        [SerializeField] private AimStrikeController aim;
        [SerializeField] private BallController ball;
        [SerializeField] private Rigidbody ballRb;
        [SerializeField] private TrajectoryPreview trajectory;
        [SerializeField] private CameraFeedback camFeedback;
        [SerializeField] private LineRenderer line;

        private void Awake()
        {
            if (!aim) aim = FindObjectOfType<AimStrikeController>();
            if (!ball) ball = FindObjectOfType<BallController>();
            if (!ballRb && ball) ballRb = ball.GetComponent<Rigidbody>();

            if (trajectory)
            {
                // Ensure a line renderer exists
                if (!line) line = trajectory.GetComponent<LineRenderer>();
                if (!line && trajectory) line = trajectory.gameObject.AddComponent<LineRenderer>();

                // default line setup (GPU-cheap)
                line.widthMultiplier = 0.01f;
                line.positionCount = 0;
                line.enabled = false;
            }

            if (ball)
            {
                ball.OnScored += _ => camFeedback?.OnScore();
            }
        }

        // Call this from your AimStrikeController when charging to show preview.
        public void UpdatePreview(Vector3 aimDir, float power01)
        {
            if (!trajectory || !ball || !ballRb) return;

            float gamma = PongConfig.Data.economy.powerCurveGamma;
            float curved = Mathf.Pow(Mathf.Clamp01(power01), gamma);
            float impulseMag = PongConfig.Data.economy.maxImpulse * Mathf.Max(0.08f, curved);

            // Convert impulse to approx initial velocity for preview.
            // v = J/m; but our impulse is in Unity "Impulse" units -> behaves like delta-v times mass.
            float m = Mathf.Max(0.001f, ballRb.mass);
            var v0 = aimDir.normalized * (impulseMag / m);

            trajectory.Preview(ball.transform.position, v0);
            trajectory.SetActive(true);
        }

        public void HidePreview()
        {
            if (trajectory) trajectory.SetActive(false);
        }

        public void NotifyStrike(float power01)
        {
            camFeedback?.OnStrike(power01);
        }
    }
}
